import React, { useState } from "react";
import { Container, Row, Col, Button, Form } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import logo from "../Assests/logo00.png";
import searchWhite from "../Assests/searchiconwhite.png";
import courseData from "./CourseData";
import "./home.css";

function Hero() {
  const [selectedCategory, setSelectedCategory] = useState("");
  const [selectedCourse, setSelectedCourse] = useState("");
  const [categorySearchTerm, setCategorySearchTerm] = useState("");
  const [courseSearchTerm, setCourseSearchTerm] = useState("");
  const navigate = useNavigate();

  const categories = [
    { key: "ALL", name: "All Courses" },
    { key: "SEG", name: "Automotive & MOT" },
    { key: "VTCT", name: "ESOL Certificates" },
    { key: "PERSONS", name: "English & Math" },
    { key: "PRO QUAL", name: "Security & Safety" },
    { key: "SQA", name: "Taxi & Private Hire" },
    { key: "ICQ", name: "Education & Training" },
  ];

  const getCoursesForCategory = () => {
    if (!selectedCategory || selectedCategory === "ALL") {
      return courseData.ALL;
    }
    return courseData[selectedCategory] || [];
  };


  const handleCategorySelect = (category) => {
    setSelectedCategory(category.key);
    setCategorySearchTerm(category.name);
    setSelectedCourse("");
    setCourseSearchTerm("");
  };

  const handleCourseSelect = (course) => {
    setSelectedCourse(course.id);
    setCourseSearchTerm(course.title);
  };


  const handleSearch = () => {
    // Always navigate to enroll page when search button is clicked
    let courseData = null;
    
    if (selectedCourse && selectedCategory) {
      // If both category and course are selected, pass the specific course data
      const course = getCoursesForCategory().find(c => c.id === selectedCourse);
      if (course) {
        courseData = {
          course,
          category: selectedCategory,
          categoryName: categories.find(cat => cat.key === selectedCategory)?.name
        };
      }
    }
    
    // Navigate to enroll page with or without course data
    navigate('/enroll', { 
      state: courseData ? courseData : { selectedCategory, categoryName: categories.find(cat => cat.key === selectedCategory)?.name }
    });
  };
  return (
    <section
      className="hero-section text-light d-flex align-items-center position-relative"
      style={{ backgroundColor: "#02AEF1", width: "100vw", marginLeft: "calc(-50vw + 50%)" }} // 👈 updated styles
    >
      <Container className="pt-5">
        <Row className="align-items-center overflow-hidden">
          <Col md={7}>
            <small
              className="text-uppercase d-flex align-items-center ls-1"
              style={{ fontSize: "11px" }}
            >
              
              Learning, Education, Training
            </small>

            <h1 className="display-5 fw-bold mt-2 playfair-display-custom">
              Sky Education <br /> Manchester Reach <br /> For the Sky
            </h1>
            <p className="mt-3" style={{ fontSize: "12px" }}>
              At Sky Education, we are dedicated to fostering learning and
              development across a broad spectrum of disciplines, from health
              and beauty to public services and education.
            </p>
          </Col>

          {/* Updated Search Box */}
          <div
            className="d-flex align-items-center justify-content-between bg-white shadow-sm px-2 px-sm-5 py-4 py-md-2 w-100 my-4 search-box overflow-hidden"
            style={{ maxWidth: "75%" }}
          >
            {/* Course Category */}
            <div
              className="d-flex flex-column px-2 mb-2 mb-sm-0"
              style={{ minWidth: "300px", width: "350px" }}
            >
              <label className="blue mb-1 text-start fw-semibold">
                Course Category
              </label>
              <div className="search-input-wrapper position-relative">
                <Form.Select
                  value={selectedCategory}
                  onChange={(e) => {
                    const categoryKey = e.target.value;
                    const category = categories.find(cat => cat.key === categoryKey);
                    if (category) {
                      handleCategorySelect(category);
                    }
                  }}
                  className="search-input border-0 border-bottom border-black rounded-0 shadow-none px-0"
                  style={{ width: "100%", backgroundColor: "transparent" }}
                >
                  <option value="">Select Course Category...</option>
                  {categories.map((category) => (
                    <option key={category.key} value={category.key}>
                      {category.name}
                    </option>
                  ))}
                </Form.Select>
              </div>
            </div>

            {/* Course Name */}
            <div
              className="d-flex flex-column px-2 ms-sm-2 mb-2 mb-sm-0"
              style={{ minWidth: "300px", width: "350px" }}
            >
              <label className="blue mb-1 text-start fw-semibold">
                Course Name
              </label>
              <div className="search-input-wrapper position-relative">
                <Form.Select
                  value={selectedCourse}
                  onChange={(e) => {
                    const courseId = parseInt(e.target.value);
                    const course = getCoursesForCategory().find(c => c.id === courseId);
                    if (course) {
                      handleCourseSelect(course);
                    }
                  }}
                  disabled={!selectedCategory}
                  className="search-input border-0 border-bottom border-black rounded-0 shadow-none px-0"
                  style={{ width: "100%", backgroundColor: "transparent" }}
                >
                  <option value="">
                    {selectedCategory ? "Select a Course..." : "First select a category"}
                  </option>
                  {selectedCategory && getCoursesForCategory().map((course) => (
                    <option key={course.id} value={course.id}>
                      {course.title}
                    </option>
                  ))}
                </Form.Select>
              </div>
            </div>

            {/* Search Button */}
            <Button
              onClick={handleSearch}
              style={{
                backgroundColor: "#02AEF1",
                border: "none",
                height: "28px",
              }}
              className="rounded-pill px-4 py-4 mt-2 ms-sm-2 d-flex align-items-center justify-content-center search-btn"
            >
              Search
              <img
                src={searchWhite}
                alt="Search"
                style={{ width: "18px", marginLeft: "6px" }}
              />
            </Button>
          </div>
        </Row>
      </Container>
    </section>
  );
}

export default Hero;